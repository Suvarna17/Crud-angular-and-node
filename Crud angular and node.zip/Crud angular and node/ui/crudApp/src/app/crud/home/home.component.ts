import { Component, OnInit } from '@angular/core';
import { CrudService } from '../crud.service';
import { User } from '../user';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(public crudService: CrudService) { }

  users: User[] = [];
  id: any;
  ngOnInit() {
    this.crudService.getAll().subscribe((data: User[]) => {
      console.log(data);

      this.users = data;

      console.log("thssssss", this.users)
    })
  }


  deleteUser(id) {
    console.log("id",id)
    this.crudService.delete(id).subscribe(res => {
      this.users = this.users.filter(item => item._id !== id);
      console.log('Post deleted successfully!');
    })
  }

}
