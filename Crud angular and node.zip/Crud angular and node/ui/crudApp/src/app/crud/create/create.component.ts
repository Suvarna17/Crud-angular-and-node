import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';
import { CrudService } from '../crud.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss']
})
export class CreateComponent implements OnInit {
  form: FormGroup;

  ngOnInit() {
      this.form = this.fb.group({
        firstName: ['',[Validators.required]],
        lastName: ['',[Validators.required]],
        email: ['',[Validators.required]],
        phoneNumber: ['',[Validators.required]],
        image:['',[Validators.required]]    
    })
  }

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public crudService: CrudService
  ){ }

  submitForm() {
    this.crudService.create(this.form.value).subscribe(res => {
      console.log('Product created!',this.form.value)
      this.router.navigateByUrl('/crud/home')

    })

  }

}


