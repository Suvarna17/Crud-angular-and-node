import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
   
import {  Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { User} from './user'

@Injectable({
  providedIn: 'root'
})
export class CrudService {


  private apiServer = "http://localhost:4000";
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  constructor(private httpClient: HttpClient) { }


  getAll(): Observable<any> {
    return this.httpClient.get(this.apiServer + '/api/user')
    .pipe(
      catchError(this.errorHandler)
    )
  }

  create(user): Observable<User[]> {
    return this.httpClient.post<User[]>(this.apiServer + '/api/user', JSON.stringify(user), this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
    )
  }   


  find(id): Observable<User> {
    return this.httpClient.get<User>(this.apiServer + '/api/user/' + id)
    .pipe(
      catchError(this.errorHandler)
    )
  }
   
  update(id, post): Observable<User> {
    return this.httpClient.put<User>(this.apiServer + '/api/user/' + id, JSON.stringify(post), this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
    )
  }
   
  delete(id){
    return this.httpClient.delete<User>(this.apiServer + '/api/user/' + id, this.httpOptions)
    .pipe(
      catchError(this.errorHandler)
    )}
  
  errorHandler(error) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
 }
}
