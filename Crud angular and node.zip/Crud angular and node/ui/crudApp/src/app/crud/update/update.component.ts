import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { CrudService } from '../crud.service';
import { User } from '../user';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.scss']
})
export class UpdateComponent implements OnInit {

  id: number;
  user: User;
  form: FormGroup;

  constructor(
    private route: ActivatedRoute,
    public fb: FormBuilder,
    private router: Router,
    public crudService: CrudService
  ) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['userId'];
    console.log("this.id", this.id)
    this.crudService.find(this.id).subscribe((data: User) => {
      this.user = data;
      console.log("hsdghsgdhs",this.user)
    });

    this.form = this.fb.group({
      firstName: [''],
      lastName: [''],
      email: [''],
      phoneNumber: [''],
      image: ['']
    })
  }


  submit() {
    console.log(this.form.value);
    this.crudService.update(this.id, this.form.value).subscribe(res => {
    console.log('Post updated successfully!');
     this.router.navigateByUrl('crud/home');
    })
  }

}
