export interface User {
        _id: number;
        firstName: string;
        lastName: string;
        email: String;
        phoneNumber: number;
        image:String;
}
