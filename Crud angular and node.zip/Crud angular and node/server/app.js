const express = require('express');
const http = require('http');
const cors = require('cors');
const app = express();
const bodyParser = require("body-parser")

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json({ limit: '50MB' }));
app.use(cors());

app.use('/api/user', require('./Routes/users'));

const port = process.env.PORT || '4000';
app.set('port', port);

const server = http.createServer(app);
server.listen(port, () => {
  console.log("***************************************");
  console.log("Running Server on port : " + port);
  console.log("***************************************");
});