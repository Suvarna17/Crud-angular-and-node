const express = require('express');
const router = express.Router();
const db = require('../Config/dbConnection')
const User = db.User;

router.get('/', (req, res) => {
    User.find().then(users => {
        res.status(200).json(users)
    }).catch(err => {
        res.status(500).json({ status: "FALUARE", Message: "error while getting users" })
    })
})

router.get('/:id',(req,res)=>{
    console.log(req.params.id)
    User.findById(req.params.id).then(users => {
        res.status(200).json(users)
    }).catch(err => {
        res.status(500).json({ status: "FALUARE", Message: "error while getting user" })
    })
})

router.post('/', (req, res) => {
    let jsonObj = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        phoneNumber: req.body.phoneNumber,
        image: req.body.image
    }
    console.log("jsonobj",jsonObj)
    const user = new User(jsonObj);
    user.save().then(data => {
        console.log("saved")
        res.status(200).json({ status: "SUCCESS", result: data })
    }).catch(err => {
        console.log(err)
        res.status(500).json({ status: "FALUARE", Message: "error while saving user" })
    })
})


router.put('/:id', (req, res) => {
    console.log("udpated body",req.body)
    let updateJson = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        phoneNumber: req.body.phoneNumber,
        image: req.body.image
    }
    User.findById(req.params.id).then(user => {
        if (user) {
            Object.assign(user, updateJson);
            user.save().then(UpdatedUser => {
                res.status(200).json({ status: "SUCCESS", result: UpdatedUser })
            })
        } else {
            console.log("User not found'");
            res.status(500).json({ status: "FALUARE", Message: "error while updating user" })
        }
    }).catch(err => {
        res.status(500).json({ status: "FALUARE", Message: "error while deleteing user" })
    })

})

router.delete('/:id', (req, res) => {
    let userId = req.params.id;
    console.log("userId", userId)
    User.findByIdAndRemove(req.params.id).then(data => {
        res.status(200).json({ status: "SUCCESS", result: data })
    }).catch(err => {
        res.status(500).json({ status: "FALUARE", Message: "error while deleteing user" })
    })
})

module.exports = router;