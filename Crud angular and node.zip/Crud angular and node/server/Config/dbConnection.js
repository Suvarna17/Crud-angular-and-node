const mongoose = require('mongoose');
const mongoDb = 'mongodb://127.0.0.1/crud'
mongoose.connect(mongoDb, { useCreateIndex: true, useNewUrlParser: true });
mongoose.Promise = global.Promise;

var db = mongoose.connection;

db.on('connected',function(){
    console.log("db connection done");
})
module.exports = {
    User: require('../Model/users')
};

